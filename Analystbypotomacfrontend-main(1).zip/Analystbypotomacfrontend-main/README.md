
  # UI Design Kit (Copy)

  This is a code bundle for UI Design Kit (Copy). The original project is available at https://www.figma.com/design/7Sj2fz9RUMcAscpZJykhO9/UI-Design-Kit--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  