// Yellow logo - New Hexagonal Design
import logo from 'figma:asset/5ce167767639106e26c3015beb74a7ba651e69bf.png';
export default logo;